<!DOCTYPE html>
<html>
<head>
 <title><?php echo lang('offer_letter') ?></title>
</head>
<body>
 
 
<h1><?php echo lang('offer_letter') ?></h1>
<table style="border:1px solid red;width:100%;">
 <tr>
 <th style="border:1px solid red">Id</th>
 <th style="border:1px solid red">Name</th>
 <th style="border:1px solid red">job name</th>
 </tr>
 <tr>
 <td style="border:1px solid red">1</td>
 <td style="border:1px solid red"><?php echo $user_data['first_name'].' '.$user_data['last_name'];?></td>
 <td style="border:1px solid red"><?php echo $job_details['job_title'];?></td>
 </tr>
<p>
	TO

WHN PVT ltd
Chicago USA
Dear Mr. Cook
I am writing this letter to thank you for considering me appropriate for the job position of system analyst in SRMB Consultancy. I am fortunate enough to get a job offer in your company and eager to work and improve with your organization in the coming years.
As it was discussed during interview my yearly salary will be $25000 with other allowances. There will be a training of 30 days at my joining so that I get to know the work procedure and other system operations of the organization. I will be able to join your group on 25th August, 2014. If any paperwork or personal evaluation is needed to be done before my joining.
I am hopeful to make sincere contribution to your company in future and assure you to work to the best of my capabilities. Thank you once again for showing confidence in me and considering me eligible enough for the position.
Yours sincerely,
Richard Collingwood.'

</p>
</table>
 
 
</body>
</html>